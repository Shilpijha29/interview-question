<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .container {
            width: 50%;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4caf50;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Submitted Registration Data</h2>
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            echo "<table>";
            echo "<tr><th>Field</th><th>Value</th></tr>";

            foreach ($_POST as $field => $value) {
                if (is_array($value)) {
                    // If the value is an array (e.g., hobbies), implode it for display
                    $value = implode(", ", $value);
                }

                echo "<tr><td>$field</td><td>$value</td></tr>";
            }

            echo "</table>";
        } else {
            echo "<p>No data submitted.</p>";
        }
        ?>
    </div>
</body>
</html>
