<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .container {
            width: 50%;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input,
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        input[type="checkbox"] {
            width: auto;
        }

        .toggle-password {
            cursor: pointer;
            user-select: none;
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
        }

        .error-message {
            color: #ff0000;
            margin-top: 5px;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Registration Form</h2>
        <form action="registration_data.php" method="post" onsubmit="return validateForm()">
            <label for="firstName">First Name:</label>
            <input type="text" name="firstName" required>

            <label for="lastName">Last Name:</label>
            <input type="text" name="lastName" required>

            <label for="gender">Gender:</label>
            <select name="gender" required>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>

            <label for="email">Email address:</label>
            <input type="email" name="email" required>

            <label for="password">Password:</label>
            <div style="position: relative;">
                <input type="password" id="password" name="password" required>
                <span class="toggle-password" onclick="togglePasswordVisibility()">👁️</span>
            </div>
            <div id="passwordError" class="error-message"></div>

            <label for="confirmPassword">Confirm Password:</label>
            <div style="position: relative;">
                <input type="password" id="confirmPassword" name="confirmPassword" required>
                <span class="toggle-password" onclick="toggleConfirmPasswordVisibility()">👁️</span>
            </div>
            <div id="confirmPasswordError" class="error-message"></div>

            <label for="hobbies">Hobbies:</label>
            <input type="checkbox" name="hobbies[]" value="Music"> Music
            <input type="checkbox" name="hobbies[]" value="Reading"> Reading
            <input type="checkbox" name="hobbies[]" value="Sports"> Sports

            <button type="submit">Submit</button>
        </form>

        <script>
            function togglePasswordVisibility() {
                const passwordInput = document.getElementById('password');
                passwordInput.type = passwordInput.type === 'password' ? 'text' : 'password';
            }

            function toggleConfirmPasswordVisibility() {
                const confirmPasswordInput = document.getElementById('confirmPassword');
                confirmPasswordInput.type = confirmPasswordInput.type === 'password' ? 'text' : 'password';
            }

            function validateForm() {
                const password = document.getElementById('password').value;
                const confirmPassword = document.getElementById('confirmPassword').value;
                const passwordError = document.getElementById('passwordError');
                const confirmPasswordError = document.getElementById('confirmPasswordError');

                if (password.length < 8) {
                    passwordError.textContent = 'Password should be at least 8 characters.';
                    return false;
                } else {
                    passwordError.textContent = '';
                }

                if (confirmPassword.length < 8) {
                    confirmPasswordError.textContent = 'Confirm Password should be at least 8 characters.';
                    return false;
                } else {
                    confirmPasswordError.textContent = '';
                }

                if (password !== confirmPassword) {
                    confirmPasswordError.textContent = 'Passwords do not match.';
                    return false;
                } else {
                    confirmPasswordError.textContent = '';
                }

                return true;
            }
        </script>
    </div>
</body>
</html>
